import React from "react";

function Banner() {
  return (
    <>
      <div></div>
    </>
  );
}

export default Banner;
