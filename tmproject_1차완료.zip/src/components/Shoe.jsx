import React from "react"

function About() {
    return <h1>Shoes 화면 입니다.</h1>;
}

export default About;